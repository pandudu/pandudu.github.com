package testSonar;

public class HelloImpl implements IHello {

    @Override
    public String hello(String to) {
        return "Say hello to " + to;
    }

}
