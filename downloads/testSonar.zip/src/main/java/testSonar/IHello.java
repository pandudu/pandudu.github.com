package testSonar;

public interface IHello {
    
    public String hello(String to);

}
